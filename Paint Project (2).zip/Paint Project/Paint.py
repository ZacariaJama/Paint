#Paint
#Theme: The Legend of Zelda
#Zacaria Jama

# Individual Features: -6 stamps -size changing tools -Auto. fill shapes -spray paint with a changing radius -smooth drawing lines -smooth cornered rectangles -cleaner looking ellipses

#Attention to Detail: -rounded cornerson the rectangles
#                     -shapes changing sizes
#                     -shapes fill automatically when the scroller is scrolled all the way back
#                     -smooth lines for drawing
#                     -radius of the spray circle is resizable and the spray effect is faster

from random import *
from pygame import *;
from math import *
from getname import *
res=(1024,768)
screen=display.set_mode(res)
backround = image.load("backround.jpg") #to display the backround theme.
screen.blit(backround, (0,0))
font.init()                                 # must have this in your program for my font to work

canvas = Rect(224, 15, 785, 568) #location and size of the canvas or drawing board

comicFont = font.SysFont("Comic Sans MS", 20) #the font used for text in this program
firstPic = image.load("blank.png") #so that the blank canvas is screenshoted so you can udo to a blank canvas



pencilRect = Rect(224,598,85,73.5) #location of the rectangles for the utensils and stamps
paintRect = Rect(224,680.5,85,73.5)
eraserRect = Rect(324,598,85,73.5)
textRect = Rect(324,680,85,73.5)
circleRect = Rect(424,598,85,73.5)
rectRect = Rect(424,680,85,73.5)
lineRect = Rect(524,598,85,73.5)
fillRect = Rect(524,680,85,73.5)
sprayRect = Rect(624,598,85,73.5)
saveRect = Rect(15,703,40,50)
loadRect = Rect(70,703,40,50)
undoRect = Rect(125,703,40,50)
redoRect = Rect(180,703,40,50)

stamp_one = Rect(15,15,85,112.67)
stamp_two = Rect(115,15,85,112.67)
stamp_three = Rect(15,142,85,112.67)
stamp_four = Rect(115,142,85,112.67)
stamp_five = Rect(15,270,85,112.67)
stamp_six = Rect(115,270,85,112.67)

color = image.load("wheel2.0.png")
tool = ()

draw.rect(screen,(255,255,255),canvas)
size = 5 #the base size for all resizable items
c = ((0))

running=True

undoList = [firstPic] #so that the last action can be undone, moved to the redo list, where the vis ersa can happen
redoList = []

while running:
    click = False
    screen.set_clip(None)
    for e in event.get():

        if e.type == QUIT:
            running=False
        if e.type == MOUSEBUTTONDOWN:
            if e.button == 1:
                click = True
                pic = screen.copy() #take a pic of the screen
                xd,yd = mouse.get_pos()
                start = e.pos
                startx = e.pos[0] #the x position of the mouse
                starty = e.pos[1] #the y position of the mouse
            if e.button == 4:
                size += 1
            if e.button == 5 and size >=1:
                size -= 1
        elif e.type == MOUSEBUTTONUP and canvas.collidepoint((mx,my)):
            frameCanvas = screen.copy().subsurface(canvas)
            undoList.append(frameCanvas) #to move any action completed on the canvas to the "undo list" so it can be undone later
            print("screen saved")

        #--------------------
        col = [(0,0,0), (255,255,255), (222,222,222), (111,111,111), (0,155,100)]

        mx,my = mouse.get_pos()
        mb = mouse.get_pressed()

        #--------------------Stamp Buttons--------------------
        draw.rect(screen,col[2],(15,15,85,112.67),3)       # 1
        draw.rect(screen,col[1],(17,17,81,108.67))

        draw.rect(screen,col[2],(115,15,85,112.67),3)       # 2
        draw.rect(screen,col[1],(117,17,81,108.67))

        draw.rect(screen,col[2],(15,142.67,85,112.67),3)       # 3
        draw.rect(screen,col[1],(17,144.67,81,108.67))

        draw.rect(screen,col[2],(115,142.67,85,112.67),3)       # 4
        draw.rect(screen,col[1],(117,144.67,81,108.67))

        draw.rect(screen,col[2],(15,270.34,85,112.67),3)       # 5
        draw.rect(screen,col[1],(17,272.34,81,108.67))

        draw.rect(screen,col[2],(115,270.34,85,112.67),3)       # 6
        draw.rect(screen,col[1],(117,272.34,81,108.67))

    #--------------------Stamp Controls--------------------
        
        toonLink = image.load("toon link3.png")
        triforce = image.load("stamp2.png")
        sword = image.load("sword2.png")
        zelda = image.load("zelda1.png")
        hook = image.load("hook1.png")
        ocarina = image.load("ocarina.png")

        screen.blit(toonLink, (19,19))
        if stamp_one.collidepoint(mx,my): #so the computer knows to complete the following action when the mouse hovers over this location
            draw.rect(screen,col[0],stamp_one,3)
            if mb[0] == 1:
                    screen.set_clip(canvas)
                    screen.blit(toonLink, (mx,my))
                    screen.set_clip(None)

        screen.blit(triforce, (119,19))
        if stamp_two.collidepoint(mx,my):
            draw.rect(screen,col[0],stamp_two,3)
            if mb[0] == 1:
                    screen.set_clip(canvas)
                    screen.blit(triforce, (mx,my))
                    screen.set_clip(None)

        screen.blit(sword, (19,142))
        if stamp_three.collidepoint(mx,my):
            draw.rect(screen,col[0],stamp_three,3)
            if mb[0] == 1:
                    screen.set_clip(canvas)
                    screen.blit(sword, (mx,my))
                    screen.set_clip(None)

        screen.blit(zelda, (119,142))
        if stamp_four.collidepoint(mx,my):
            draw.rect(screen,col[0],stamp_four,3)
            if mb[0] == 1:
                    screen.set_clip(canvas)
                    screen.blit(zelda, (mx,my))
                    screen.set_clip(None)

        screen.blit(hook, (19,270))
        if stamp_five.collidepoint(mx,my):
            draw.rect(screen,col[0],stamp_five,3)
            if mb[0] == 1:
                    screen.set_clip(canvas)
                    screen.blit(hook, (mx,my))
                    screen.set_clip(None)

        screen.blit(hook, (119,270))
        if stamp_five.collidepoint(mx,my):
            draw.rect(screen,col[0],stamp_five,3)
            if mb[0] == 1:
                    screen.set_clip(canvas)
                    screen.blit(hook, (mx,my))
                    screen.set_clip(None) 

    #--------------------Music-------------------- #the music file was corrupt, so It can't work
    #init()
    #mixer.music.load("Lorule Castle - The Legend of Zelda A Link Between Worlds - Music Extended.mp3")
    #mixer.music.play(-1)

    #--------------------Colour area--------------------
    
    screen.blit(color, (15,395,270,270))
    draw.circle(screen,col[0],(100,480),22)
    if mb[0] == 1 and mx<185 and my>395 and mx>14 and my<603:
        c = screen.get_at((mx,my)) #get the colour value of the clicked location on the screen

    #--------------------Save/Load Buttons--------------------

    draw.rect(screen,col[2],(15,703,40,50),3)
    draw.rect(screen,col[1],(17,705,36,46))
    if saveRect.collidepoint(mx,my):
        draw.rect(screen,col[0],saveRect,3)#tohighlight the border, so the user knows his mouse is there
        if click:
            txt = getName(screen,False)                     # this is how you would call my getName function
            image.save(screen.subsurface(canvas),txt)                  # your main loop will stop looping until user hits enter




    draw.rect(screen,col[2],(70,703,40,50),3)
    draw.rect(screen,col[1],(72,705,36,46))
    if loadRect.collidepoint(mx,my):
        draw.rect(screen,col[0],loadRect,3)
        if click:
            txt = getName(screen,False)
            loadScreen = image.load(txt)
            screen.blit(loadScreen, (canvas))

    #--------------------Undo/Redo Buttons--------------------

    draw.rect(screen,col[2],(125,703,40,50),3)
    draw.rect(screen,col[1],(125,705,38,46))
    if undoRect.collidepoint(mx,my):
        draw.rect(screen,col[0],undoRect,3)
        #if mb[0] == 1: #undo/redo are incomplete and do not work yet
            #screen.blit(undoList[-1])
            #del.undoList(-1)
            #redoList.append()

    #--------------------Utensil Button Looks--------------------

    draw.rect(screen,col[3],pencilRect,3)
    draw.rect(screen,col[1],(226,600,81,69.5))

    draw.rect(screen,col[3],paintRect,3)
    draw.rect(screen,col[1],(226,682,81,69.5))

    draw.rect(screen,col[3],sprayRect,3)
    draw.rect(screen,col[1],(626,600,81,69.5))

    for x in range(324,624,100): #where the utencil buttons are located
        for y in range(598,680,82):
            draw.rect(screen,col[3],(x,y,85,73.5),3)
            draw.rect(screen,col[1],(x+2,y+2,81,69.5))
            draw.rect(screen,col[3],(x,680,85,73.5),3)
            draw.rect(screen,col[1],(x+2,682,81,69.5))

    pencil = image.load("rsz_pencil.png")
    screen.blit(pencil, (226,600))
    brush = image.load("brush1.jpg")
    screen.blit(brush, (226, 682.5))
    eraser = image.load("eraser1.png")
    screen.blit(eraser, (326,600))
    text = image.load("text2.png")
    screen.blit(text, (326,682.5))
    circle = image.load("circle2.png")
    screen.blit(circle, (429,600))
    rect = image.load("rect3.png")
    screen.blit(rect, (429,682.5))
    line = image.load("line2.png")
    screen. blit(line, (529,600))
    spray = image.load("spray1.png")
    screen.blit(spray, (626,600))
    save = image.load("save.jpg")
    screen.blit(save, (18,706))
    load = image.load("load1.png")
    screen.blit(load, (73,706))

    #--------------------Utensil Buttons--------------------

    if pencilRect.collidepoint(mx,my):
        draw.rect(screen,col[0],pencilRect,3)
        if mb[0] == 1:
            tool = "pencil" #so that more than one tool can't be selected at the same time 
    elif paintRect.collidepoint(mx,my):
        draw.rect(screen,col[0],paintRect,3)
        if mb[0] == 1:
            tool = "paint"
    elif eraserRect.collidepoint(mx,my):
        draw.rect(screen,col[0],eraserRect,3)
        if mb[0] == 1:
            tool = "eraser"
    elif textRect.collidepoint(mx,my):
        draw.rect(screen,col[0],textRect,3)
        if mb[0] == 1:
            tool = "text"
    elif circleRect.collidepoint(mx,my):
        draw.rect(screen,col[0],circleRect,3)
        if mb[0]== 1:
            tool = "circle"
    elif rectRect.collidepoint(mx,my):
        draw.rect(screen,col[0],rectRect,3)
        if mb[0] == 1:
            tool = "rect"
    elif lineRect.collidepoint(mx,my):
        draw.rect(screen,col[0],lineRect,3)
        if mb[0] == 1:
            tool = "line"
    elif fillRect.collidepoint(mx,my):
        draw.rect(screen,col[0],fillRect,3)
        if mb[0] == 1:
            tool = "fill"
    elif sprayRect.collidepoint(mx,my):
        draw.rect(screen,col[0],sprayRect,3)
        if mb[0] == 1:
            tool = "spray"

    #--------------------Utensil Controls--------------------

    if canvas.collidepoint(mx,my):
        if mb[0] == 1:
            if tool == "pencil":
                screen.set_clip(canvas)
                draw.line(screen,c,(omx,omy),(mx,my), 3)
                screen.set_clip(None)
            if tool == "paint":
                screen.set_clip(canvas)
                dist=hypot(mx-omx,my-omy)
                for i in  range(int(dist)):
                    sx=(mx-omx)/dist
                    sy=(my-omy)/dist
                    draw.circle(screen,c,(int(omx+i*sx),int(omy+i*sy)), size) #so that a circle appears for every pixel the mouse moves, appearing along the line already being drawn.
                draw.circle(screen,c,(mx,my),size) #so that a circle appears where your mouse is as well
                screen.set_clip(None)
            if tool == "eraser":
                screen.set_clip(canvas)
                dist=hypot(mx-omx,my-omy)
                for i in  range(int(dist)):
                    sx=(mx-omx)/dist
                    sy=(my-omy)/dist
                    draw.circle(screen,col[1],(int(omx+i*sx),int(omy+i*sy)), size)
                draw.circle(screen,col[1],(mx,my),5)
                screen.set_clip(None)

            if tool == "text":
                if click:
                    txt = getName(screen,False)
                    txtPic = comicFont.render(txt, True, (0,0,0))
                    screen.blit(txtPic,(mx,my))
                elif txt == "":
                    getName(screen,False)



            if tool == "rect":
                screen.set_clip(canvas)
                screen.blit(pic,(0,0))
                draw.rect(screen,c,(startx,starty,mx-startx,my-starty), size)
                draw.circle(screen,c,(mx,my),size//2) #so circles appear at each of the 4 corners, to round them out
                draw.circle(screen,c,(startx,my),size//2)
                draw.circle(screen,c,(mx,starty),size//2)
                draw.circle(screen,c,(startx,starty),size//2)
                screen.set_clip(None)

            if tool == "circle":
                screen.set_clip(canvas)
                screen.blit(pic, (0,0))
                elRect = Rect(startx,starty,(mx-startx),(my-starty))
                ellipse = Rect(start[0], start[1], mx-start[0],my-start[1])
                ellipse2 = Rect(start[0]+1, start[1]+1, mx-start[0],my-start[1])
                ellipse3 = Rect(start[0]-1, start[1]-1, mx-start[0],my-start[1])
                ellipse.normalize()# so the alues of the elipses location CAN be negitive
                ellipse2.normalize()
                ellipse3.normalize()
                if ellipse.width < size*2 or ellipse.height < size*2:
                    draw.ellipse(screen,c,(ellipse)) #automatically fill the ellipse if the sides are touching
                else:
                    draw.ellipse(screen,c,(ellipse),size)
                    draw.ellipse(screen,c,(ellipse2),size)# so the ellipse looks more solid
                    draw.ellipse(screen,c,(ellipse3),size)
                screen.set_clip(None)

            if tool == "line":
                screen.set_clip(canvas)
                screen.blit(pic, (0,0))
                draw.line(screen, c, start, (mx,my), size)
                screen.set_clip(None)

            #if tool == "fill" #does not work


            if tool == "spray":
                screen.set_clip(canvas)
                for i in range(30): #controlsthe speed of the spray's partical effect
                    sprayx = randint(-size,size) #the "size" variables here can be changed, resizing the radius of the circles spray
                    sprayy = randint(-size,size)
                    if hypot(sprayx,sprayy) <= size:
                        screen.set_at((mx+sprayx,my+sprayy),c)
                screen.set_clip(None)

    #--------------------Message Box--------------------


    #------------------
    display.flip()
    omx=mx #original mouse posistion before an action
    omy=my

quit() #so you can close the program
